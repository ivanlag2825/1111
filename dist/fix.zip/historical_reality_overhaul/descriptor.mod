version="0.6.1"
tags={ "Historical" "National Focuses" "Events" }
name="Historical Reality: Total War 1936-1946"
supported_version="1.*"
