version="0.1.0"
tags={ "Historical" "National Focuses" "Events" }
name="Historical Reality: Germany & USSR"
supported_version="1.*"
