Historical Reality: Германия и СССР

1. Закрой HOI4 и Paradox Launcher.
2. Распакуй historical_reality (папку) и historical_reality.mod (файл) в:
   Документы/Paradox Interactive/Hearts of Iron IV/mod/
   Если Документы перенесены в OneDrive, используй фактическую папку данных HOI4.
3. В Paradox Launcher добавь Historical Reality: Germany & USSR в набор модов
   и включи его. Для первой проверки отключи другие моды деревьев и карты.
4. Начни новую кампанию 1936 года с историческим ИИ. Новые ветки находятся
   справа от исходных. К ним добавлен отдельный ярлык навигации дерева.

Правильная структура:
   Hearts of Iron IV/mod/historical_reality.mod
   Hearts of Iron IV/mod/historical_reality/descriptor.mod
   Hearts of Iron IV/mod/historical_reality/common/...

В папку установленной игры/Steam ничего копировать не нужно.
Python и запуск установщика для этого архива не нужны.
Исторический разбор: historical_reality/docs/HISTORY_RU.md.
Если уже установлена старая версия HRS, предварительно сохрани её отдельно:
не смешивай содержимое разных версий.

Архив привязан к исходным файлам игры, использованным при сборке.
После обновления HOI4 потребуется новая сборка. Статическая проверка не заменяет
проверку в движке; наличие архива само по себе не подтверждает игровой баланс.
