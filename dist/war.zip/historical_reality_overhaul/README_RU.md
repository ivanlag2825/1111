# Historical Reality: Total War 1936–1946 — 0.4.0

Большая переработка для двух игроков: Германия против СССР. Основной сценарий — новая историческая кампания 1936 года со всеми DLC и возможностью отклонения от истории. Срок поддержанного контента — до 1946 года.

## Установка

1. Выключи прежние Historical Reality 0.1/0.2/0.3 и другие моды деревьев/баланса GER/SOV. При обновлении замени старую папку `historical_reality_overhaul` новой.
2. Распакуй папку `historical_reality_overhaul` и файл `historical_reality_overhaul.mod` в `Документы/Paradox Interactive/Hearts of Iron IV/mod`.
3. Включи **Historical Reality: Total War 1936-1946** в одном и том же наборе у обоих игроков. У обоих должны совпадать версия игры, DLC и checksum.
4. Начните НОВУЮ кампанию 1936 года. Для стран под управлением ИИ включите исторические фокусы. Правило HRO по умолчанию сохраняет исторические окна подготовки; «Свободные сроки» снимает только добавленные условия даты.
5. Основные промышленные и военные ветки переработаны прямо в обычных деревьях. Голубые узлы на приложенной схеме — новые; для ключевых исходных реформ они теперь обязательны. Восемь ярлыков помогают перейти к нужному направлению.

## Содержание

Исходных ID сохранено 749; индивидуально изменены 214 исходных узлов. Связи переделаны у 67 исходных фокусов, расположение — у 199. Добавлено 81 новых фокусов. Проверена обязательность новых этапов для 32 объявленных переходов к основным реформам.

Дерево содержит развилки специализации, объединяющие этапы и связи промышленности с перевооружением. Награды включают реальные предприятия, существенные исследовательские ускорения, ограниченное расширение исследований и национальные реформы. Все исходные награды, политические последствия и вызовы событий DLC сохранены; их условия и снятие дебаффов продолжают действовать.

У каждой страны собственные начальные институциональные слабости. Последовательные фокусы улучшают их до устойчивых преимуществ. Текущие духи видны в окне страны; завершение старой реформы позднее не откатывает уже достигнутую стадию HRO. Взаимоисключающие программы требуют выбора приоритета.

Промышленность, армия, снабжение, авиация, флот, государственное управление, дипломатия и адаптация в войне образуют связанные направления. Не требуется закрыть все ветки до 1946 года: очередь фокусов остаётся ограниченным ресурсом.

Общие программы требуют политической власти и временных издержек. Промышленная, оперативная и управленческая программы выполняются в разных слотах. Полезный результат выдаётся после окончания подготовки; отмена не приносит награду. Фоновые MEFO, паранойя, настоящая эвакуация и политические системы DLC сохранены; старые две шкалы HRS 0.1 не используются.

## Восточный фронт: подготовка, кризис, адаптация

При первом оборонительном вступлении СССР в войну с Германией возникает новый кризис: организация −25%, её восстановление −25%, скорость планирования −35%, военный выпуск −20%, потребление снабжения +25%. Он длится 120 фактических дней войны; в мирное время опыт не накапливается. «Проверка мобилизационных округов» заранее смягчает кризис до −10% организации/выпуска и +10% снабжения. После острой фазы штраф ослабевает даже без реформ.

«Отчёты фронтов вместо сводок» закрепляют полную советскую адаптацию. После накопления опыта новые штрафы снимаются, а страна получает +25% восстановления организации, +35% планирования, +25% максимального плана, +10% военного выпуска и −10% снабжения. При советском наступлении дополнительной внезапности нет; опыт и реформа остаются доступны. Исходные ограничения Красной армии продолжают действовать по правилам DLC.

Германия во время войны с СССР получает зимние ограничения с ноября по март: без подготовки первая зима даёт +30% расхода снабжения, +75% зимнего истощения, −25% восстановления организации, −15% скорости и −30% планирования. «Единый моторный парк» смягчает кризис. «Континентальная система снабжения» вместе с 45 фактическими зимними днями войны снимает новые штрафы и даёт −40% зимнего истощения, +100% холодовой акклиматизации, −10% снабжения и +15% восстановления организации. Летом, в мирное время и после капитуляции сезонные штрафы убираются.

Заранее завершённые реформы запоминаются. Они не требуют повторного прохождения фокуса, но результат опыта включается после нужного числа военных/зимних дней. Ступени штрафов не складываются, повторное вступление в войну не выдаёт вторую награду. Это ежедневная проверка двух стран, поэтому изменение состояния может появиться на следующем игровом дне. Для версии 0.4 нужна новая кампания: старые сохранения не содержат истории новых счётчиков.

Награды основных реформ существенно усилены. Например, поздняя германская серийная школа даёт +25% выпуска и +25% предела эффективности ценой −15% её роста; гибкая школа — +40% роста и +35% сохранения эффективности. Советская промышленная семья достигает +25% выпуска, оборонная строительная школа — +45% военного строительства. Полные пакеты и издержки перечислены в `docs/REWARDS_040_RU.md`.

Панель непрерывных фокусов перемещена ниже всех узлов и положительных условных смещений. Координаты записаны в `OVERHAUL_BUILD_REPORT.json`; схема теперь показывает и панель.

## Проверка и ограничения

Проверены структура файлов, ссылки, графы, локализация, упаковка и соответствие исходным ID. Работа предыдущей лёгкой версии подтверждена пользователем. ЭТА версия ещё не запускалась в HOI4: сетевой баланс, ответы ИИ и фактическая совместимость требуют тестовой партии.

Это масштабная интеграция и переработка фокусов, а не замена всех скрытых скриптов DLC. Исходные определения событий и фоновых систем пользователь не передавал, поэтому они используются через сохранённые игровые этапы. После обновления игры нужна новая сборка под изменившиеся исходные файлы.

Открой `preview/index.html` в браузере: это интерактивная схема фактических связей и координат сборки с поиском и масштабом. Она не заменяет проверку отображения в игре: скрытие политических веток и условные смещения рассчитывает движок HOI4.

Игроки могут договариваться о политических правилах и сроке начала большой войны; мод не навязывает победителя, автокапитуляцию, передачу чужой территории или безусловное принятие сделок противником. Переговорные войны и замена мирной конференции не реализованы.

Для ошибки пришли относящиеся к HRO строки `logs/error.log`, номер версии и описание шага. Для сетевой рассинхронизации нужны наблюдения от обоих игроков. Проверку лучше начать с нескольких месяцев за обе страны, затем с реформ и военного периода.

## Изменённые исходные этапы


### GER

- GER_prioritize_economic_growth (`GER_prioritize_economic_growth`), стоимость 5 недель.
- GER_the_four_year_plan (`GER_the_four_year_plan`), стоимость 3 недель.
- GER_construct_the_reichsautobahn (`GER_construct_the_reichsautobahn`), стоимость 3 недель.
- GER_autarky_efforts (`GER_autarky_efforts`), стоимость 3 недель.
- GER_institute_price_controls (`GER_institute_price_controls`), стоимость 3 недель.
- GER_establish_the_reichswerke (`GER_establish_the_reichswerke`), стоимость 5 недель.
- GER_coal_liquefaction (`GER_coal_liquefaction`), стоимость 5 недель.
- GER_subsidize_hoesch_benzin (`GER_subsidize_hoesch_benzin`), стоимость 3 недель.
- GER_establish_buna_werke (`GER_establish_buna_werke`), стоимость 5 недель.
- GER_accelerate_the_rearmament_program (`GER_accelerate_the_rearmament_program`), стоимость 3 недель.
- GER_establish_production_targets (`GER_establish_production_targets`), стоимость 3 недель.
- GER_zentrale_planung (`GER_zentrale_planung`), стоимость 5 недель.
- GER_create_rustungsstab (`GER_create_rustungsstab`), стоимость 5 недель.
- GER_armament_rationalization (`GER_armament_rationalization`), стоимость 5 недель.
- GER_totaler_krieg (`GER_totaler_krieg`), стоимость 5 недель.
- GER_develop_modern_maneuver_warfare (`GER_develop_modern_maneuver_warfare`), стоимость 3 недель.
- GER_the_prussian_legacy (`GER_the_prussian_legacy`), стоимость 3 недель.
- GER_improve_motorized_troops (`GER_improve_motorized_troops`), стоимость 3 недель.
- GER_lessons_of_the_great_war (`GER_lessons_of_the_great_war`), стоимость 3 недель.
- GER_artillery_bombardment (`GER_artillery_bombardment`), стоимость 3 недель.
- GER_stormtroopers (`GER_stormtroopers`), стоимость 3 недель.
- GER_instill_auftragstaktik (`GER_instill_auftragstaktik`), стоимость 3 недель.
- GER_panzergrenadier (`GER_panzergrenadier`), стоимость 5 недель.
- GER_kriegslokomotiven (`GER_kriegslokomotiven`), стоимость 3 недель.
- GER_improve_the_logistics_system (`GER_improve_the_logistics_system`), стоимость 5 недель.
- GER_adopt_new_panzer_doctrine (`GER_adopt_new_panzer_doctrine`), стоимость 5 недель.
- GER_panzer_troops_school (`GER_panzer_troops_school`), стоимость 3 недель.
- GER_combined_arms (`GER_combined_arms`), стоимость 5 недель.
- GER_expanding_the_luftwaffe (`GER_expanding_the_luftwaffe`), стоимость 3 недель.
- GER_aeronautical_research_institute (`GER_aeronautical_research_institute`), стоимость 5 недель.
- GER_dive_bombers (`GER_dive_bombers`), стоимость 3 недель.
- GER_tactical_bombers (`GER_tactical_bombers`), стоимость 3 недель.
- GER_form_the_jagdwaffe (`GER_form_the_jagdwaffe`), стоимость 5 недель.
- GER_reorganize_the_luftwaffe (`GER_reorganize_the_luftwaffe`), стоимость 5 недель.
- GER_solve_the_logistical_bottlenecks (`GER_solve_the_logistical_bottlenecks`), стоимость 3 недель.
- GER_defense_of_the_reich (`GER_defense_of_the_reich`), стоимость 5 недель.
- GER_strengthen_the_kriegsmarine (`GER_strengthen_the_kriegsmarine`), стоимость 3 недель.
- GER_plan_z (`GER_plan_z`), стоимость 5 недель.
- GER_trade_interdiction (`GER_trade_interdiction`), стоимость 5 недель.
- GER_wolfpack_tactics (`GER_wolfpack_tactics`), стоимость 3 недель.
- GER_u_boat_efforts (`GER_u_boat_efforts`), стоимость 5 недель.
- GER_reorganize_the_wehrmacht (`GER_reorganize_the_wehrmacht`), стоимость 5 недель.
- GER_anschluss (`GER_anschluss`), стоимость 10 недель.
- GER_molotov_ribbentrop_pact (`GER_molotov_ribbentrop_pact`), стоимость 5 недель.
- GER_war_with_the_ussr (`GER_war_with_the_ussr`), стоимость 10 недель.
- GER_currency_reforms (`GER_currency_reforms`).
- GER_lower_taxes (`GER_lower_taxes`).
- GER_abolish_price_controls (`GER_abolish_price_controls`).
- GER_increased_trade (`GER_increased_trade`).
- GER_housing_developments (`GER_housing_developments`).
- GER_workers_rights (`GER_workers_rights`).
- GER_industrial_expansion (`GER_industrial_expansion`).
- GER_invest_in_vereinigte_stahlwerke (`GER_invest_in_vereinigte_stahlwerke`).
- GER_agricultural_reforms (`GER_agricultural_reforms`).
- GER_urbanization (`GER_urbanization`).
- GER_wirtschaftswunder (`GER_wirtschaftswunder`).
- GER_mass_production (`GER_mass_production`).
- GER_build_defense_industry (`GER_build_defense_industry`).
- GER_war_production (`GER_war_production`).
- GER_build_the_rur_dam (`GER_build_the_rur_dam`).
- GER_trade_deal_with_sweden (`GER_trade_deal_with_sweden`).
- GER_kdf_wagen_factories (`GER_kdf_wagen_factories`).
- GER_expand_the_reichsautobahn_south (`GER_expand_the_reichsautobahn_south`).
- GER_expand_the_reichsautobahn_east (`GER_expand_the_reichsautobahn_east`).
- GER_develop_heraeus_facilities (`GER_develop_heraeus_facilities`).
- GER_seize_foreign_industries (`GER_seize_foreign_industries`).
- GER_autarky_achieved (`GER_autarky_achieved`).
- GER_concentrated_armament_program (`GER_concentrated_armament_program`).
- GER_fortify_the_vaterland (`GER_fortify_the_vaterland`).
- GER_all_terrain_military_motorcycle (`GER_all_terrain_military_motorcycle`).
- GER_salvage_captured_equipment (`GER_salvage_captured_equipment`).
- GER_establish_the_afrikakorps (`GER_establish_the_afrikakorps`).
- GER_establish_the_skijager (`GER_establish_the_skijager`).
- GER_nationalize_ford_factories (`GER_nationalize_ford_factories`).
- GER_defend_the_vaterland (`GER_defend_the_vaterland`).
- GER_uranverein (`GER_uranverein`).
- GER_advanced_panzer_research (`GER_advanced_panzer_research`).
- GER_expand_kummersdorfs_capacity (`GER_expand_kummersdorfs_capacity`).
- GER_uralbomber_program (`GER_uralbomber_program`).
- GER_rocketry_innovations (`GER_rocketry_innovations`).
- GER_fallschirmjager (`GER_fallschirmjager`).
- GER_experimental_rotorcrafts (`GER_experimental_rotorcrafts`).
- GER_develop_the_knickebein (`GER_develop_the_knickebein`).
- GER_construct_the_kammhuber_line (`GER_construct_the_kammhuber_line`).
- GER_establish_night_fighter_squadrons (`GER_establish_night_fighter_squadrons`).
- GER_torpedobomber (`GER_torpedobomber`).
- GER_establish_carrier_groups (`GER_establish_carrier_groups`).
- GER_aerodynamic_research_institute (`GER_aerodynamic_research_institute`).
- GER_amerikabomber (`GER_amerikabomber`).
- GER_expand_kriegsmarinewerft (`GER_expand_kriegsmarinewerft`).
- GER_construct_aircraft_carriers (`GER_construct_aircraft_carriers`).
- GER_grosskampfschiff_construction (`GER_grosskampfschiff_construction`).
- GER_high_seas_fleet (`GER_high_seas_fleet`).
- GER_re_establish_the_seekriegsleitung (`GER_re_establish_the_seekriegsleitung`).
- GER_marinestosstrupp (`GER_marinestosstrupp`).
- GER_atlantic_naval_bases (`GER_atlantic_naval_bases`).
- GER_atlantic_naval_dominance (`GER_atlantic_naval_dominance`).
- GER_cruiser_warfare (`GER_cruiser_warfare`).
- GER_panzerschiff_raiders (`GER_panzerschiff_raiders`).
- GER_unrestricted_convoy_raiding (`GER_unrestricted_convoy_raiding`).
- GER_seeherrschaft (`GER_seeherrschaft`).
- GER_fuhrerprinzip (`GER_fuhrerprinzip`).

### Новые программы

**Промышленная программа:** Промышленность на военном учёте; Станкостроительная программа; Длинные серии вооружения; Гибкие производственные группы; Единые комплекты поставок; Комиссия стандартных конструкций; Рассредоточить оборонные предприятия; Арсенал затяжной войны; Вторая очередь синтетических комбинатов.

**Армия и командование:** Генеральный штаб новой войны; Самостоятельность полевых штабов; Единая оперативная школа; Общевойсковые манёвры; Корпус ремонта и пополнений; Оперативные резервы фронта; Военно-технические академии; Вооружённые силы 1946 года.

**Транспорт и снабжение:** Штаб военных перевозок; Приоритет магистральным дорогам; Приоритет дорожным колоннам; Единый моторный парк; Континентальная система снабжения.

**Воздушная стратегия:** Штаб воздушной войны; Авиация непосредственной поддержки; Воздушный щит промышленности; Приёмка и рассредоточение авиапрома; Авианаводчики передовых соединений; Реактивное перевооружение.

**Военно-морская программа:** Морская программа вооружения; Конструкторское бюро эскортов; Серийные секции подлодок; Единое командование морских операций; Морская оборона континента.

**Государство и тыл:** Разграничить военные полномочия; Чрезвычайный хозяйственный штаб; Полномочия техническим комиссиям; Восстановление без капитуляции.

**Внешняя политика:** Континентальные торговые соглашения.

**Адаптация и восстановление:** Распределение ресурсов большой войны; Резервы для многолетней войны.


### SOV

- SOV_infrastructure_effort_nsb (`SOV_infrastructure_effort_nsb`), стоимость 3 недель.
- SOV_heavy_industry (`SOV_heavy_industry`), стоимость 5 недель.
- SOV_finish_the_five_year_plan (`SOV_finish_the_five_year_plan`), стоимость 4 недель.
- SOV_improve_railway_network (`SOV_improve_railway_network`), стоимость 3 недель.
- SOV_third_five_year_plan (`SOV_third_five_year_plan`), стоимость 4 недель.
- SOV_reorganize_the_pc_of_heavy_industry (`SOV_reorganize_the_pc_of_heavy_industry`), стоимость 4 недель.
- SOV_industrial_modernization (`SOV_industrial_modernization`), стоимость 5 недель.
- SOV_increase_state_reserves (`SOV_increase_state_reserves`), стоимость 3 недель.
- SOV_shift_to_armaments_production (`SOV_shift_to_armaments_production`), стоимость 4 недель.
- SOV_optimize_production_lines (`SOV_optimize_production_lines`), стоимость 5 недель.
- SOV_steel_casting_industry (`SOV_steel_casting_industry`), стоимость 7 недель.
- SOV_eastern_development (`SOV_eastern_development`), стоимость 3 недель.
- SOV_develop_the_urals (`SOV_develop_the_urals`), стоимость 3 недель.
- SOV_found_the_pcdi (`SOV_found_the_pcdi`), стоимость 3 недель.
- SOV_military_engineering_university (`SOV_military_engineering_university`), стоимость 3 недель.
- SOV_strengthen_the_mobilization_plan (`SOV_strengthen_the_mobilization_plan`), стоимость 3 недель.
- SOV_cohesion_first (`SOV_cohesion_first`), стоимость 2 недель.
- SOV_rehabilitated_military (`SOV_rehabilitated_military`), стоимость 5 недель.
- SOV_military_reorganization (`SOV_military_reorganization`), стоимость 4 недель.
- SOV_desperate_measures (`SOV_desperate_measures`), стоимость 5 недель.
- SOV_an_adaptable_army (`SOV_an_adaptable_army`), стоимость 7 недель.
- SOV_lessons_of_war (`SOV_lessons_of_war`), стоимость 5 недель.
- SOV_the_defense_of_moscow (`SOV_the_defense_of_moscow`), стоимость 3 недель.
- SOV_the_molotov_line (`SOV_the_molotov_line`), стоимость 7 недель.
- SOV_improve_the_stalin_line (`SOV_improve_the_stalin_line`), стоимость 7 недель.
- SOV_transpolar_flights (`SOV_transpolar_flights`), стоимость 3 недель.
- SOV_expand_the_aircraft_industry (`SOV_expand_the_aircraft_industry`), стоимость 7 недель.
- SOV_modernize_aircraft_facilities (`SOV_modernize_aircraft_facilities`), стоимость 4 недель.
- SOV_merge_aircraft_plants (`SOV_merge_aircraft_plants`), стоимость 3 недель.
- SOV_foster_flying_clubs (`SOV_foster_flying_clubs`), стоимость 3 недель.
- SOV_ground_support (`SOV_ground_support`), стоимость 7 недель.
- SOV_long_range_aircraft (`SOV_long_range_aircraft`), стоимость 7 недель.
- SOV_expand_the_red_fleet (`SOV_expand_the_red_fleet`), стоимость 3 недель.
- SOV_reinforce_western_naval_bases (`SOV_reinforce_western_naval_bases`), стоимость 3 недель.
- SOV_pc_of_the_ussr_navy (`SOV_pc_of_the_ussr_navy`), стоимость 3 недель.
- SOV_surface_warfare (`SOV_surface_warfare`), стоимость 4 недель.
- SOV_addressing_internal_affairs (`SOV_addressing_internal_affairs`), стоимость 3 недель.
- SOV_the_new_soviet_woman (`SOV_the_new_soviet_woman`), стоимость 3 недель.
- SOV_expand_the_agitprop (`SOV_expand_the_agitprop`), стоимость 3 недель.
- SOV_policy_of_collective_security (`SOV_policy_of_collective_security`), стоимость 5 недель.
- SOV_seek_a_defense_pact_with_the_allies (`SOV_seek_a_defense_pact_with_the_allies`), стоимость 5 недель.
- SOV_policy_of_individual_security (`SOV_policy_of_individual_security`), стоимость 5 недель.
- SOV_reconcile_japan (`SOV_reconcile_japan`), стоимость 10 недель.
- SOV_restoration_and_development (`SOV_restoration_and_development`), стоимость 5 недель.
- SOV_fourth_five_year_plan (`SOV_fourth_five_year_plan`), стоимость 7 недель.
- SOV_synthetic_rubber (`SOV_synthetic_rubber`).
- SOV_oil_production (`SOV_oil_production`).
- SOV_found_the_comecon (`SOV_found_the_comecon`).
- SOV_the_common_economic_space_initiative (`SOV_the_common_economic_space_initiative`).
- SOV_found_the_warsaw_pact (`SOV_found_the_warsaw_pact`).
- SOV_no_time_for_peace (`SOV_no_time_for_peace`).
- SOV_national_specialists (`SOV_national_specialists`), стоимость 3 недель.
- SOV_foreign_experts (`SOV_foreign_experts`), стоимость 3 недель.
- SOV_the_ussr_academy_of_sciences (`SOV_the_ussr_academy_of_sciences`), стоимость 5 недель.
- SOV_national_academies_of_sciences (`SOV_national_academies_of_sciences`).
- SOV_transformation_of_nature (`SOV_transformation_of_nature`).
- SOV_transformation_of_nature_alt (`SOV_transformation_of_nature_alt`).
- SOV_found_the_jet_institute (`SOV_found_the_jet_institute`).
- SOV_increase_aircraft_production (`SOV_increase_aircraft_production`).
- SOV_women_in_aviation (`SOV_women_in_aviation`).
- SOV_raskovas_aviation_group (`SOV_raskovas_aviation_group`).
- SOV_intensify_pilot_training_program (`SOV_intensify_pilot_training_program`).
- SOV_expand_aviation_institutes (`SOV_expand_aviation_institutes`).
- SOV_the_modern_war_in_the_skies (`SOV_the_modern_war_in_the_skies`).
- SOV_reinforce_northern_naval_bases (`SOV_reinforce_northern_naval_bases`).
- SOV_reinforce_southern_naval_bases (`SOV_reinforce_southern_naval_bases`).
- SOV_reinforce_eastern_naval_bases (`SOV_reinforce_eastern_naval_bases`).
- SOV_expand_shipbuilding_plants (`SOV_expand_shipbuilding_plants`).
- SOV_merge_naval_plants (`SOV_merge_naval_plants`).
- SOV_submarine_warfare (`SOV_submarine_warfare`), стоимость 4 недель.
- SOV_offensive_maritime_strategy (`SOV_offensive_maritime_strategy`).
- SOV_an_oceangoing_navy (`SOV_an_oceangoing_navy`).
- SOV_mine_warfare (`SOV_mine_warfare`).
- SOV_long_range_raiders (`SOV_long_range_raiders`).
- SOV_advanced_maneuvers (`SOV_advanced_maneuvers`).
- SOV_expand_the_morskaya_aviatsiya (`SOV_expand_the_morskaya_aviatsiya`).
- SOV_naval_infantry (`SOV_naval_infantry`).
- SOV_pc_of_mechanical_engineering (`SOV_pc_of_mechanical_engineering`), стоимость 3 недель.
- SOV_superior_war_machines (`SOV_superior_war_machines`), стоимость 3 недель.
- SOV_the_means_to_wage_war (`SOV_the_means_to_wage_war`), стоимость 3 недель.
- SOV_soviet_artillery (`SOV_soviet_artillery`).
- SOV_pc_of_mortar_armament (`SOV_pc_of_mortar_armament`).
- SOV_development_of_tankograd (`SOV_development_of_tankograd`).
- SOV_merge_tank_and_materiel_plants (`SOV_merge_tank_and_materiel_plants`).
- SOV_leningrad_polytechnical_institute (`SOV_leningrad_polytechnical_institute`).
- SOV_soviet_atomic_bomb_project (`SOV_soviet_atomic_bomb_project`).
- SOV_move_industry_to_the_urals (`SOV_move_industry_to_the_urals`).
- SOV_the_road_of_life (`SOV_the_road_of_life`).
- SOV_impregnable_forts (`SOV_impregnable_forts`).
- SOV_protect_the_white_sea_baltic_canal (`SOV_protect_the_white_sea_baltic_canal`).
- SOV_far_east_fortification (`SOV_far_east_fortification`).
- SOV_restore_cossack_units (`SOV_restore_cossack_units`), стоимость 2 недель.
- SOV_penal_battalions (`SOV_penal_battalions`).
- SOV_organization_of_the_partisans (`SOV_organization_of_the_partisans`).
- SOV_smersh (`SOV_smersh`).
- SOV_barrier_troops (`SOV_barrier_troops`).
- SOV_experts_in_camouflage (`SOV_experts_in_camouflage`).
- SOV_keep_commissars_organization (`SOV_keep_commissars_organization`).
- SOV_adjoined_battle_priests (`SOV_adjoined_battle_priests`).
- SOV_swap_to_political_advisors (`SOV_swap_to_political_advisors`).
- SOV_the_glory_of_the_red_army (`SOV_the_glory_of_the_red_army`).
- SOV_the_glory_of_the_red_army_alt (`SOV_the_glory_of_the_red_army_alt`).
- SOV_nkvd_primacy (`SOV_nkvd_primacy`).
- SOV_rebuild_the_nation (`SOV_rebuild_the_nation`).
- SOV_the_komsomol (`SOV_the_komsomol`).

### Новые программы

**Промышленная программа:** Ревизия второй пятилетки; Пятилетка оборонных комбинатов; Уголь, сталь и новые города; От чертежа к массовой серии; Единая технологическая оснастка; Уральская производственная база; Совет прикладной науки; Четвёртая пятилетка: новые мощности.

**Армия и командование:** Академия Генерального штаба; Радиосети Генерального штаба; Эшелонированная оборона фронтов; Самостоятельные механизированные группы; Фронт как единая операция; Т-34: единый промышленный стандарт; Арсеналы массового вооружения.

**Транспорт и снабжение:** Наркомат путей сообщения; Площадки приёма эвакуируемых заводов; Автомобильные батальоны фронтов; Тыл на глубину операции.

**Воздушная стратегия:** Боевые лётные школы; Испытания новых авиамоторов; Воздушные армии фронтов; Корпуса ПВО промышленных районов; Единое командование ВВС; Реактивная авиация нового поколения.

**Военно-морская программа:** Штаб морских коммуникаций; Приоритет защиты коммуникаций; Большой флот новой державы; Единая морская воздушная разведка; Верфи четырёх морей.

**Государство и тыл:** Госплан: ответственность за результат; Государственный комитет обороны; Восстановление союзных республик.

**Внешняя политика:** Наркомат иностранных дел: две стратегии; Закупки станков и технические миссии.

**Адаптация и восстановление:** Отчёты фронтов вместо сводок; Проверка мобилизационных округов; Резервные армии Ставки; Зимнее снабжение действующей армии; Ставка: последовательные наступления; Советская армия 1946 года.

