version="1.9.3"
tags={ "Historical" "National Focuses" "Events" }
name="Historical Reality: Total War 1936-1946"
supported_version="1.19.*"
path="mod/historical_reality_overhaul"
